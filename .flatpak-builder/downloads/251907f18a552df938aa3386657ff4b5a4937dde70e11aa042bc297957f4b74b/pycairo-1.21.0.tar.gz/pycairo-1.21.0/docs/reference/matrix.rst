.. _matrix:

******
Matrix
******

.. currentmodule:: cairo


class Matrix()
==============

.. autoclass:: Matrix
    :members:
    :undoc-members:

    .. automethod:: __init__
