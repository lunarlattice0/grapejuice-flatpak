.. |python-logo| raw:: html

    <i class="icon-python"></i>


.. |ubuntu-logo| raw:: html

    <i class="icon-ubuntu"></i>

.. |debian-logo| raw:: html

    <i class="icon-debian"></i>

.. |fedora-logo| raw:: html

    <i class="icon-fedora"></i>

.. |opensuse-logo| raw:: html

    <i class="icon-suse"></i>

.. |windows-logo| raw:: html

    <i class="fa fa-windows"></i>

.. |source-logo| raw:: html

    <i class="fa fa-file"></i>

.. |arch-logo| raw:: html

    <i class="icon-archlinux"></i>

.. |macosx-logo| raw:: html

    <i class="fa fa-apple"></i>

.. |github-logo| raw:: html

    <i class="fa fa-github"></i>

.. |git-logo| raw:: html

    <i class="fa fa-git-square"></i>

.. |bug-logo| raw:: html

    <i class="fa fa-bug"></i>

.. |linux-logo| raw:: html

    <i class="fa fa-linux"></i>
